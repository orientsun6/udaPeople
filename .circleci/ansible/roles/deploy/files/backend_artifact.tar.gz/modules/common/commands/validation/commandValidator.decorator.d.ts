import 'reflect-metadata';
import { ICommand } from '../ICommand';
export declare const CommandValidator: (command: ICommand) => ClassDecorator;
