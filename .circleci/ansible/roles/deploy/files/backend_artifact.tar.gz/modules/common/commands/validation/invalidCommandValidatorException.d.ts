export declare class InvalidCommandValidatorException extends Error {
    constructor();
}
