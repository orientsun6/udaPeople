"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class BaseCommandHandler {
    execute(command) {
        return this.handle(command);
    }
}
exports.BaseCommandHandler = BaseCommandHandler;
//# sourceMappingURL=baseCommandHandler.js.map