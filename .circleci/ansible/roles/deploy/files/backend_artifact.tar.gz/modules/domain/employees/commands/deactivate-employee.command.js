"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class DeactivateEmployee {
    constructor(employeeId, isActive) {
        this.employeeId = employeeId;
        this.isActive = isActive;
    }
}
exports.DeactivateEmployee = DeactivateEmployee;
//# sourceMappingURL=deactivate-employee.command.js.map