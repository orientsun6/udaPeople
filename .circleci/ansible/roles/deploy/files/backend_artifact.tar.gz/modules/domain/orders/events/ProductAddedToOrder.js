"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ProductAddedToOrder {
    constructor(orderId, productId) {
        this.orderId = orderId;
        this.productId = productId;
    }
}
exports.ProductAddedToOrder = ProductAddedToOrder;
//# sourceMappingURL=ProductAddedToOrder.js.map