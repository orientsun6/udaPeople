"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeePersonalEmail {
    constructor(employeeId, personalEmail) {
        this.employeeId = employeeId;
        this.personalEmail = personalEmail;
    }
}
exports.UpdateEmployeePersonalEmail = UpdateEmployeePersonalEmail;
//# sourceMappingURL=update-employee-personal-email.command.js.map