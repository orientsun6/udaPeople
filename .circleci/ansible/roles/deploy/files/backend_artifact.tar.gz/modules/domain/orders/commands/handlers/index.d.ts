import { OrderCreator } from './orderCreator';
export declare const CommandHandlers: (typeof OrderCreator)[];
