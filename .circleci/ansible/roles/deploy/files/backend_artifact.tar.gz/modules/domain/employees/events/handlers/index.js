"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const notify_employee_created_console_handler_1 = require("./notify-employee-created-console.handler");
exports.EventHandlers = [notify_employee_created_console_handler_1.NotifyEmployeeCreatedConsole];
//# sourceMappingURL=index.js.map