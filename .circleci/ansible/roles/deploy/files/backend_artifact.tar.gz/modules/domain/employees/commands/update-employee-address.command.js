"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeAddress {
    constructor(employeeId, address, country, region, city) {
        this.employeeId = employeeId;
        this.address = address;
        this.region = region;
        this.country = country;
        this.city = city;
    }
}
exports.UpdateEmployeeAddress = UpdateEmployeeAddress;
//# sourceMappingURL=update-employee-address.command.js.map