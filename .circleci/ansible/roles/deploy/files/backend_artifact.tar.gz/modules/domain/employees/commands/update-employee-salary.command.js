"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeSalary {
    constructor(employeeId, salary) {
        this.employeeId = employeeId;
        this.salary = salary;
    }
}
exports.UpdateEmployeeSalary = UpdateEmployeeSalary;
//# sourceMappingURL=update-employee-salary.command.js.map