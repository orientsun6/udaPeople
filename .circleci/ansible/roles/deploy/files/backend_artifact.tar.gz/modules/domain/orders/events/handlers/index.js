"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const notify_product_add_to_order_console_1 = require("./notify-product-add-to-order-console");
exports.EventHandlers = [notify_product_add_to_order_console_1.NotifyProductAddToOrderConsole];
//# sourceMappingURL=index.js.map