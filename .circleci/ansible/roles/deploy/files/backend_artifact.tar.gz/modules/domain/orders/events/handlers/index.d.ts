import { NotifyProductAddToOrderConsole } from './notify-product-add-to-order-console';
export declare const EventHandlers: (typeof NotifyProductAddToOrderConsole)[];
