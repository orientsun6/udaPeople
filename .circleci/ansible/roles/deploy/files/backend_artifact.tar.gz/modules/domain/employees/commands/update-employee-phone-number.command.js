"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeePhoneNumber {
    constructor(employeeId, phoneNumber) {
        this.employeeId = employeeId;
        this.phoneNumber = phoneNumber;
    }
}
exports.UpdateEmployeePhoneNumber = UpdateEmployeePhoneNumber;
//# sourceMappingURL=update-employee-phone-number.command.js.map