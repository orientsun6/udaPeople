export declare const Usr: (...dataOrPipes: any[]) => ParameterDecorator;
