import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddEmployee1555722583168 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<any>;
    down(queryRunner: QueryRunner): Promise<any>;
}
